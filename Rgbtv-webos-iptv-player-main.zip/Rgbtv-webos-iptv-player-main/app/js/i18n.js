/* RGBTv — i18n: English (LTR) / Arabic (RTL). ES5, no build step.
 * Usage: I18n.t('key') ; markup: data-i18n="key" (textContent) / data-i18n-ph="key" (placeholder). */
var I18n = (function () {
  var EN = {
    'pair.btn': 'Add from phone', 'pair.title': 'Add a server from your phone', 'pair.s1': 'Connect your phone to the same Wi-Fi as the TV.', 'pair.s2': 'Scan the QR code (or type the address in the phone browser).', 'pair.s3': 'Fill in the server details on the phone and tap Send.', 'pair.s4': 'The profile appears here automatically and connects.', 'pair.waiting': 'Waiting for your phone…', 'pair.received': 'Received "{n}" — connecting…', 'pair.noLan': 'No network address found. Check the TV Wi-Fi / LAN connection.', 'pair.noService': 'Phone pairing needs the TV app (not available in this browser).', 'pair.set.d': 'Show a QR code; type the server details on your phone instead of the remote.', 'pair.alt': 'or open this address in your phone browser', 'pair.starting': 'Starting…', 'pair.firewall': 'If the phone cannot open the page, allow RGBTv through the Windows Firewall (private networks) and make sure the PC and phone share the same Wi-Fi.', 'pair.hint': 'Add servers from your phone without the remote', 'acc.add': 'Add Profile', 'acc.manage': 'Manage Profiles', 'acc.done': 'Done', 'acc.who': "Who's watching?", 'acc.first': 'Create your first profile', 'acc.mac': 'Device MAC (Stalker)', 'acc.redhint': 'RED button = profile menu',
    'leg.fav': 'Favorite', 'leg.mylist': 'My List', 'leg.lock': 'Lock', 'leg.guide': 'Guide', 'leg.play': 'Play', 'leg.live': 'Live TV', 'leg.search': 'Search', 'leg.details': 'Details', 'leg.epg': 'Mini EPG', 'leg.stats': 'Stats', 'leg.ratio': 'Aspect',
    'an.next': 'Up next', 'an.hint': 'OK: play now · BACK: cancel', 'an.playing': 'Playing next episode…',
    'set.layout': 'Interface style', 'set.layout.d': 'Classic (hero + rows) · Spotlight · Trio · Mosaic · Dashboard. Hub styles replace the top menu with big tiles.', 'lay.classic': 'Classic', 'lay.spotlight': 'Spotlight', 'lay.trio': 'Trio', 'lay.mosaic': 'Mosaic', 'lay.dashboard': 'Dashboard',
    'set.accent': 'Accent color', 'set.accent.d': 'Color of highlights, buttons and progress bars. Auto follows the theme.', 'accent.auto': 'Auto',
    'set.pointer': 'Magic Remote pointer', 'set.pointer.d': 'Click only: pointing at items does nothing, only the OK button selects. Hover: pointing moves the highlight.', 'pointer.click': 'Click only (OK)', 'pointer.hover': 'Hover highlights',
    'set.corners': 'Corners', 'set.corners.d': 'Rounded or square cards, tiles and buttons.', 'corners.round': 'Rounded', 'corners.square': 'Square',
    'set.glow': 'Background glow', 'set.glow.d': 'Soft colored light behind the interface and under the highlight. Turn off for a flat look.',
    'theme.crimson': 'Crimson', 'theme.emerald': 'Emerald', 'theme.sunset': 'Sunset', 'theme.royal': 'Royal',
    'hub.home': 'Home', 'retry': 'Retry', 'conn.failed': 'Connection failed', 'remove': 'Remove', 'close': 'Close', 'edit': 'Edit', 'hub.hello': 'Welcome back', 'hub.recent': 'Recently watched',
    'set.focus': 'Focus style', 'set.focus.d': 'How the highlighted item looks: Glow · Classic ring · Zoom only.', 'focus.glow': 'Glow', 'focus.ring': 'Ring', 'focus.zoom': 'Zoom',
    'set.large': 'Large UI', 'set.large.d': 'Bigger text, posters and lists — easier to read from the sofa.',
    'set.liveGrid': 'Live TV channel style', 'set.liveGrid.d': 'List with EPG, or a grid of channel logos.', 'live.list': 'List', 'live.grid': 'Logo grid',
    'set.ambient': 'Ambient screensaver', 'set.ambient.d': 'After 5 minutes idle (outside the player) show a clock with slow artwork slideshow.',
    'nav.weather': 'Weather', 'hub.weather': 'Weather',
    'nav.adhan': 'Adhan', 'hub.adhan': 'Prayer times', 'set.adhan': 'Adhan & prayer times', 'set.adhan.d': 'Prayer-time banner on top of everything, even while watching. Same location as the weather.', 'set.adhan.open': 'Open',
    'adhan.fajr': 'Fajr', 'adhan.sunrise': 'Sunrise', 'adhan.dhuhr': 'Dhuhr', 'adhan.asr': 'Asr', 'adhan.maghrib': 'Maghrib', 'adhan.isha': 'Isha',
    'adhan.next': 'Next prayer', 'adhan.inHM': 'in {h} h {m} min', 'adhan.inM': 'in {m} min', 'adhan.tomorrow': 'tomorrow', 'adhan.kicker': 'Time for prayer', 'adhan.itsTime': 'It is time for {p}',
    'adhan.hintClose': 'Press any button to close', 'adhan.toast': 'Adhan: {p}',
    'adhan.settings': 'Adhan settings', 'adhan.method': 'Calculation', 'adhan.enabled': 'Prayer times', 'adhan.test': 'Preview',
    'adhan.m.algeria': 'Algeria', 'adhan.m.mwl': 'Muslim World League', 'adhan.m.egypt': 'Egypt', 'adhan.m.makkah': 'Umm al-Qura (Makkah)', 'adhan.m.isna': 'ISNA', 'adhan.m.france': 'France (UOIF)', 'adhan.m.turkey': 'Turkey (Diyanet)', 'adhan.m.morocco': 'Morocco', 'adhan.m.tunisia': 'Tunisia',
    'adhan.off': 'Prayer times are off', 'adhan.off.d': 'Turn them on to see today\'s times and get a notification at prayer time — even while watching.', 'adhan.enable': 'Turn on', 'adhan.unavailable': 'Prayer times unavailable', 'adhan.source': 'Times: AlAdhan.com',
    'wx.clear': 'Clear sky', 'wx.mclear': 'Mainly clear', 'wx.pcloudy': 'Partly cloudy', 'wx.overcast': 'Overcast', 'wx.fog': 'Fog', 'wx.drizzle': 'Drizzle', 'wx.rain': 'Rain', 'wx.hrain': 'Heavy rain', 'wx.snow': 'Snow', 'wx.hsnow': 'Heavy snow', 'wx.showers': 'Showers', 'wx.storm': 'Thunderstorm', 'wx.hail': 'Thunderstorm with hail',
    'wx.feels': 'Feels like', 'wx.humidity': 'Humidity', 'wx.wind': 'Wind', 'wx.rainChance': 'Rain chance', 'wx.uv': 'UV index', 'wx.sunrise': 'Sunrise', 'wx.sunset': 'Sunset', 'wx.hourly': 'Next 24 hours', 'wx.daily': '{n}-day forecast', 'wx.now': 'Now', 'wx.today': 'Today', 'wx.updated': 'Updated {t}',
    'wx.auto': 'Automatic (by network)', 'wx.auto.d': 'Detected from your internet connection', 'wx.manual': 'Manual', 'wx.setLocation': 'Location', 'wx.changeLocation': 'Change location', 'wx.searchCity': 'Type a city name…', 'wx.noResults': 'No city found', 'wx.unavailable': 'Weather unavailable', 'wx.unavailable.d': 'Check the internet connection, or set your city manually.',
    'set.weather': 'Weather', 'set.weather.d': 'Forecast section in the menu and a small chip next to the clock (Open-Meteo, no key). Choose the location and unit.',
    'set.autonext': 'Auto-play next episode', 'set.autonext.d': '10-second countdown at the end of an episode.',
    'hub.live': 'Live TV', 'hub.live.s': '{n} channels', 'hub.movies': 'Movies', 'hub.movies.s': '{n} titles', 'hub.series': 'Series', 'hub.series.s': '{n} shows', 'hub.fav': 'My List', 'hub.fav.s': '{n} items', 'hub.guide': 'TV Guide', 'hub.guide.s': 'What\'s on now', 'hub.search': 'Search', 'hub.settings': 'Settings', 'hub.profiles': 'Profiles', 'hub.refresh': 'Refresh', 'hub.continue': 'Continue watching', 'hub.expires': 'Subscription', 'hub.account': 'Profile',
    'det.movie': 'Movie', 'det.series': 'Series', 'det.cast': 'Cast', 'det.similar': 'More like this', 'det.seasons': '{n} seasons', 'det.episodes': '{n} episodes', 'det.resume': 'Resume {t}',
    'last.watched': 'Last: {t}', 'newBadge': '+{n} new',
    // topnav
    'nav.home': 'Home', 'nav.live': 'Live TV', 'nav.guide': 'Guide', 'nav.movies': 'Movies', 'nav.series': 'Series', 'nav.favorites': 'Favorites', 'nav.search': 'Search', 'nav.settings': 'Settings',
    // generic
    'ok': 'OK', 'cancel': 'Cancel', 'back': 'Back', 'play': '▶ Play', 'details': 'Details', 'resume': 'Resume', 'trailer': 'Trailer', 'favorite': '☆ Favorite', 'favorited': '★ Favorite', 'exit': 'Exit', 'switch': 'Switch', 'clear': 'Clear', 'on': 'On', 'off': 'Off', 'now': 'Now', 'next': 'NEXT', 'nowLbl': 'NOW',
    'loading': 'Loading…', 'buffering': 'Buffering…', 'reconnecting': 'Reconnecting… ({n}/{max})', 'opening': 'Opening stream… {s}s', 'retrying': 'Retrying…',
    // home
    'home.welcome': 'Welcome back, {name}', 'home.tagline': 'Live TV, Movies and Series from {src}.', 'home.continue': 'Continue Watching', 'home.recentLive': 'Recently Watched Channels', 'home.mylist': 'My List', 'home.latestMovies': 'Latest Movies', 'home.latestSeries': 'Latest Series', 'home.liveChannels': 'Live Channels', 'home.latestMovie': 'Latest Movie', 'home.onNow': 'On Now — My Channels', 'home.onNowHint': 'Add channels to My List (RED) to see what is on right now.', 'home.empty': 'Nothing to show yet. Browse Live TV, Movies or Series.', 'home.latestAddition': 'Latest addition', 'home.featured': 'Featured', 'home.trending': 'Top Rated',
    'home.live': 'LIVE', 'home.upnext': 'Up next', 'home.min': 'min', 'home.left': 'left',
    // live / browse
    'categories': 'Categories', 'allChannels': 'All Channels', 'allMovies': 'All Movies', 'allSeries': 'All Series', 'selectChannel': 'Select a channel', 'noEpg': 'No EPG data', 'noChannels': 'No channels in this category.', 'noEpisodes': 'No episodes found.', 'locked': 'Locked', 'lockedChannel': 'Locked channel', 'enterPin': 'Enter PIN to unlock', 'lockChannel': 'Lock channel', 'unlockChannel': 'Unlock channel', 'channelLocked': 'Channel locked', 'channelUnlocked': 'Channel unlocked', 'setPinFirst': 'Set a profile PIN first (Manage Profiles) to lock channels.',
    // favorites/search
    'fav.channels': 'Favorite Channels', 'fav.movies': 'Favorite Movies', 'fav.series': 'Favorite Series', 'fav.empty': 'Your list is empty. Press RED or ☆ on any channel, movie or series.', 'search.ph': 'Search channels, movies, series…', 'search.min': 'Type at least 2 characters.', 'search.channels': 'Channels', 'search.movies': 'Movies', 'search.series': 'Series', 'search.none': 'No results for “{q}”', 'search.abc': 'ABC', 'search.ar': 'عربي',
    // settings
    'settings': 'Settings', 'set.language': 'Language', 'set.language.d': 'Interface language and layout direction.', 'set.theme': 'Theme', 'set.theme.d': 'Aurora · Midnight · OLED · Ocean · Crimson · Emerald · Sunset · Royal', 'set.liveFormat': 'Live stream format', 'set.liveFormat.d': 'Xtream only. HLS works on more TVs; TS is lower latency.', 'set.engine': 'Player engine', 'set.engine.d': 'Auto tries native first then hls.js.', 'set.parental': 'Parental control', 'set.parental.d': 'Hide adult categories.', 'set.preview': 'Live preview window', 'set.preview.d': 'Play the highlighted channel in the small preview. Turn off on slow TVs.', 'set.autostart': 'Auto-start last profile', 'set.autostart.d': 'Skip the profile screen on launch (PIN still required).', 'set.refresh': 'Auto-refresh playlists', 'set.refresh.d': 'Reload channels, movies and series in the background and notify you about new content.', 'set.tmdb': 'TMDB artwork & ratings', 'set.tmdb.d': 'Optional. Paste a TMDB API key (v3) to enrich movies & series with backdrops, plots and ratings.', 'set.cache': 'Clear cache', 'set.cache.d': 'Remove cached categories, lists, EPG and artwork.', 'set.profile': 'Profile', 'set.about': 'About', 'set.exit': 'Exit App', 'set.refreshNow': 'Refresh now', 'set.lockedKids': 'Locked (Kids)',
    'theme.aurora': 'Aurora', 'theme.midnight': 'Midnight', 'theme.oled': 'OLED Black', 'theme.ocean': 'Ocean',
    'refresh.off': 'Off', 'refresh.h': 'Every {h} h',
    // player
    'p.audio': 'Audio', 'p.subs': 'Subtitles', 'p.channels': 'Channels', 'p.stats': 'Stats', 'p.fit': 'Fit', 'p.fill': 'Fill', 'p.stretch': 'Stretch', 'p.aspect': 'Aspect: {m}', 'p.noChannel': 'No channel {n}', 'p.retryHint': '— gave up after {max} attempts. Press OK to retry.', 'p.interrupted': 'Stream interrupted — reconnecting ({n}/{max})', 'p.stalled': 'Stream stalled', 'p.error': 'Playback error', 'p.cannotLoad': 'Cannot load stream', 'p.zapHint': 'OK: switch · BACK: cancel',
    'stats.title': 'Stream statistics', 'stats.res': 'Resolution', 'stats.bitrate': 'Bitrate', 'stats.dropped': 'Dropped frames', 'stats.decoded': 'Decoded frames', 'stats.buffer': 'Buffer', 'stats.codec': 'Codec / Container', 'stats.engine': 'Engine', 'stats.latency': 'Live latency', 'stats.url': 'Stream', 'stats.unknown': 'n/a', 'stats.native': 'Native (webOS)', 'stats.hlsjs': 'hls.js',
    // toasts / misc
    'toast.favAdd': 'Added to My List', 'toast.favDel': 'Removed from My List', 'toast.cache': 'Cache cleared', 'toast.newContent': '{n} new item(s) added to your playlist', 'toast.newMovies': '{n} new movie(s)', 'toast.newSeries': '{n} new series', 'toast.newLive': '{n} new channel(s)', 'toast.refreshed': 'Playlists refreshed — no new content', 'toast.refreshing': 'Refreshing playlists…', 'toast.expires': 'Subscription: {t}',
    'exp.expired': 'Expired', 'exp.today': 'Expires today', 'exp.one': 'Expires in 1 day', 'exp.days': 'Expires in {d} days', 'exp.unlimited': 'Unlimited',
    'exit.title': 'Exit RGBTv?', 'exit.text': 'Switch profile or exit the app?', 'exit.switch': 'Switch profile', 'exit.close': 'Close the application?',
    'kids.locked': 'Parental control is locked for Kids profiles',
    'wrongPin': 'Wrong PIN, try again', 'enterPin4': 'Enter the 4-digit PIN', 'pinProtected': 'This profile is protected'
  };
  var AR = {
    'pair.btn': 'إضافة من الهاتف', 'pair.title': 'أضف سيرفرًا من هاتفك', 'pair.s1': 'صِل هاتفك بنفس شبكة Wi-Fi الخاصة بالتلفاز.', 'pair.s2': 'امسح رمز QR (أو اكتب العنوان في متصفح الهاتف).', 'pair.s3': 'املأ بيانات السيرفر على الهاتف واضغط إرسال.', 'pair.s4': 'يظهر البروفايل هنا تلقائيًا ويتصل.', 'pair.waiting': 'في انتظار هاتفك…', 'pair.received': 'تم استلام «{n}» — جارٍ الاتصال…', 'pair.noLan': 'لم يُعثر على عنوان شبكة. تحقق من اتصال التلفاز بالشبكة.', 'pair.noService': 'الإضافة من الهاتف تحتاج تطبيق التلفاز (غير متاحة في المتصفح).', 'pair.set.d': 'اعرض رمز QR واكتب بيانات السيرفر من هاتفك بدل الريموت.', 'pair.alt': 'أو افتح هذا العنوان في متصفح هاتفك', 'pair.starting': 'جارٍ التشغيل…', 'pair.firewall': 'إذا لم تُفتح الصفحة على الهاتف، اسمح لـ RGBTv في جدار حماية Windows (الشبكات الخاصة) وتأكد أن الحاسوب والهاتف على نفس شبكة Wi-Fi.', 'pair.hint': 'أضف السيرفرات من هاتفك بدون الريموت', 'acc.add': 'إضافة ملف', 'acc.manage': 'إدارة الملفات', 'acc.done': 'تم', 'acc.who': 'من يشاهد؟', 'acc.first': 'أنشئ ملفك الأول', 'acc.mac': 'عنوان MAC (Stalker)', 'acc.redhint': 'الزر الأحمر = قائمة الملف',
    'leg.fav': 'المفضلة', 'leg.mylist': 'قائمتي', 'leg.lock': 'قفل', 'leg.guide': 'الدليل', 'leg.play': 'تشغيل', 'leg.live': 'البث المباشر', 'leg.search': 'بحث', 'leg.details': 'التفاصيل', 'leg.epg': 'دليل مصغّر', 'leg.stats': 'إحصائيات', 'leg.ratio': 'الأبعاد',
    'an.next': 'التالي', 'an.hint': 'OK: تشغيل الآن · BACK: إلغاء', 'an.playing': 'تشغيل الحلقة التالية…',
    'set.layout': 'نمط الواجهة', 'set.layout.d': 'كلاسيكي (بانر + صفوف) · بؤرة · ثلاثي · فسيفساء · لوحة. الأنماط المربّعة تستبدل القائمة العلوية ببلاطات كبيرة.', 'lay.classic': 'كلاسيكي', 'lay.spotlight': 'بؤرة', 'lay.trio': 'ثلاثي', 'lay.mosaic': 'فسيفساء', 'lay.dashboard': 'لوحة',
    'set.accent': 'لون التمييز', 'set.accent.d': 'لون التحديد والأزرار وأشرطة التقدّم. تلقائي يتبع المظهر.', 'accent.auto': 'تلقائي',
    'set.pointer': 'مؤشر الريموت السحري', 'set.pointer.d': 'نقر فقط: التأشير على العناصر لا يفعل شيئًا، زر OK وحده يختار. تمرير: التأشير يحرّك التحديد.', 'pointer.click': 'نقر فقط (OK)', 'pointer.hover': 'التمرير يحدّد',
    'set.corners': 'الزوايا', 'set.corners.d': 'بطاقات وبلاطات وأزرار بزوايا دائرية أو مربّعة.', 'corners.round': 'دائرية', 'corners.square': 'مربّعة',
    'set.glow': 'توهّج الخلفية', 'set.glow.d': 'إضاءة ملوّنة ناعمة خلف الواجهة وتحت التحديد. أوقفها لمظهر مسطّح.',
    'theme.crimson': 'قرمزي', 'theme.emerald': 'زمرّدي', 'theme.sunset': 'غروب', 'theme.royal': 'ملكي',
    'hub.home': 'الرئيسية', 'retry': 'إعادة المحاولة', 'conn.failed': 'فشل الاتصال', 'remove': 'حذف', 'close': 'إغلاق', 'edit': 'تعديل', 'hub.hello': 'أهلًا بعودتك', 'hub.recent': 'شوهد مؤخرًا',
    'set.focus': 'شكل التحديد', 'set.focus.d': 'مظهر العنصر المحدد: توهّج · إطار كلاسيكي · تكبير فقط.', 'focus.glow': 'توهّج', 'focus.ring': 'إطار', 'focus.zoom': 'تكبير',
    'set.large': 'واجهة كبيرة', 'set.large.d': 'نصوص وملصقات وقوائم أكبر — أسهل للقراءة من بعيد.',
    'set.liveGrid': 'شكل قنوات البث المباشر', 'set.liveGrid.d': 'قائمة مع دليل البرامج، أو شبكة شعارات القنوات.', 'live.list': 'قائمة', 'live.grid': 'شبكة شعارات',
    'set.ambient': 'شاشة التوقف', 'set.ambient.d': 'بعد 5 دقائق من الخمول (خارج المشغّل) تُعرض ساعة مع صور بطيئة.',
    'nav.weather': 'الطقس', 'hub.weather': 'الطقس',
    'nav.adhan': 'الأذان', 'hub.adhan': 'مواقيت الصلاة', 'set.adhan': 'الأذان ومواقيت الصلاة', 'set.adhan.d': 'تنبيه عند دخول وقت الصلاة فوق كل شيء، حتى أثناء المشاهدة. نفس موقع الطقس.', 'set.adhan.open': 'فتح',
    'adhan.fajr': 'الفجر', 'adhan.sunrise': 'الشروق', 'adhan.dhuhr': 'الظهر', 'adhan.asr': 'العصر', 'adhan.maghrib': 'المغرب', 'adhan.isha': 'العشاء',
    'adhan.next': 'الصلاة القادمة', 'adhan.inHM': 'بعد {h} س {m} د', 'adhan.inM': 'بعد {m} دقيقة', 'adhan.tomorrow': 'غدًا', 'adhan.kicker': 'حان وقت الصلاة', 'adhan.itsTime': 'حان الآن موعد أذان {p}',
    'adhan.hintClose': 'اضغط أي زر للإغلاق', 'adhan.toast': 'الأذان: {p}',
    'adhan.settings': 'إعدادات الأذان', 'adhan.method': 'طريقة الحساب', 'adhan.enabled': 'مواقيت الصلاة', 'adhan.test': 'تجربة',
    'adhan.m.algeria': 'الجزائر', 'adhan.m.mwl': 'رابطة العالم الإسلامي', 'adhan.m.egypt': 'مصر', 'adhan.m.makkah': 'أم القرى (مكة)', 'adhan.m.isna': 'ISNA', 'adhan.m.france': 'فرنسا', 'adhan.m.turkey': 'تركيا', 'adhan.m.morocco': 'المغرب', 'adhan.m.tunisia': 'تونس',
    'adhan.off': 'مواقيت الصلاة متوقفة', 'adhan.off.d': 'فعّلها لعرض مواقيت اليوم والتنبيه عند دخول وقت الصلاة — حتى أثناء المشاهدة.', 'adhan.enable': 'تفعيل', 'adhan.unavailable': 'مواقيت الصلاة غير متاحة', 'adhan.source': 'المواقيت: AlAdhan.com',
    'wx.clear': 'سماء صافية', 'wx.mclear': 'صافٍ غالبًا', 'wx.pcloudy': 'غائم جزئيًا', 'wx.overcast': 'غائم', 'wx.fog': 'ضباب', 'wx.drizzle': 'رذاذ', 'wx.rain': 'مطر', 'wx.hrain': 'مطر غزير', 'wx.snow': 'ثلج', 'wx.hsnow': 'ثلج كثيف', 'wx.showers': 'زخات مطر', 'wx.storm': 'عاصفة رعدية', 'wx.hail': 'عاصفة رعدية مع بَرَد',
    'wx.feels': 'الإحساس', 'wx.humidity': 'الرطوبة', 'wx.wind': 'الرياح', 'wx.rainChance': 'احتمال المطر', 'wx.uv': 'مؤشر UV', 'wx.sunrise': 'الشروق', 'wx.sunset': 'الغروب', 'wx.hourly': 'الـ 24 ساعة القادمة', 'wx.daily': 'توقعات {n} أيام', 'wx.now': 'الآن', 'wx.today': 'اليوم', 'wx.updated': 'آخر تحديث {t}',
    'wx.auto': 'تلقائي (حسب الشبكة)', 'wx.auto.d': 'يُحدَّد من اتصال الإنترنت', 'wx.manual': 'يدوي', 'wx.setLocation': 'الموقع', 'wx.changeLocation': 'تغيير الموقع', 'wx.searchCity': 'اكتب اسم المدينة…', 'wx.noResults': 'لم يُعثر على مدينة', 'wx.unavailable': 'الطقس غير متاح', 'wx.unavailable.d': 'تحقّق من الإنترنت أو حدّد مدينتك يدويًا.',
    'set.weather': 'الطقس', 'set.weather.d': 'قسم توقعات في القائمة وشارة صغيرة بجانب الساعة (Open-Meteo بدون مفتاح). اختر الموقع والوحدة.',
    'set.autonext': 'تشغيل الحلقة التالية تلقائيًا', 'set.autonext.d': 'عدّ تنازلي 10 ثوانٍ عند نهاية الحلقة.',
    'hub.live': 'البث المباشر', 'hub.live.s': '{n} قناة', 'hub.movies': 'أفلام', 'hub.movies.s': '{n} عنوان', 'hub.series': 'مسلسلات', 'hub.series.s': '{n} مسلسل', 'hub.fav': 'قائمتي', 'hub.fav.s': '{n} عنصر', 'hub.guide': 'دليل البرامج', 'hub.guide.s': 'ماذا يُعرض الآن', 'hub.search': 'بحث', 'hub.settings': 'الإعدادات', 'hub.profiles': 'البروفايلات', 'hub.refresh': 'تحديث', 'hub.continue': 'متابعة المشاهدة', 'hub.expires': 'الاشتراك', 'hub.account': 'البروفايل',
    'det.movie': 'فيلم', 'det.series': 'مسلسل', 'det.cast': 'طاقم التمثيل', 'det.similar': 'مشابه لهذا', 'det.seasons': '{n} مواسم', 'det.episodes': '{n} حلقة', 'det.resume': 'استئناف {t}',
    'last.watched': 'آخر مشاهدة: {t}', 'newBadge': '+{n} جديد',
    'nav.home': 'الرئيسية', 'nav.live': 'البث المباشر', 'nav.guide': 'الدليل', 'nav.movies': 'أفلام', 'nav.series': 'مسلسلات', 'nav.favorites': 'المفضلة', 'nav.search': 'بحث', 'nav.settings': 'الإعدادات',
    'ok': 'موافق', 'cancel': 'إلغاء', 'back': 'رجوع', 'play': '▶ تشغيل', 'details': 'التفاصيل', 'resume': 'استئناف', 'trailer': 'الإعلان', 'favorite': '☆ المفضلة', 'favorited': '★ المفضلة', 'exit': 'خروج', 'switch': 'تبديل', 'clear': 'مسح', 'on': 'مفعّل', 'off': 'متوقف', 'now': 'الآن', 'next': 'التالي', 'nowLbl': 'الآن',
    'loading': 'جارٍ التحميل…', 'buffering': 'جارٍ التخزين المؤقت…', 'reconnecting': 'إعادة الاتصال… ({n}/{max})', 'opening': 'جارٍ فتح البث… {s} ث', 'retrying': 'إعادة المحاولة…',
    'home.welcome': 'مرحبًا بعودتك، {name}', 'home.tagline': 'قنوات مباشرة وأفلام ومسلسلات من {src}.', 'home.continue': 'متابعة المشاهدة', 'home.recentLive': 'قنوات شاهدتها مؤخرًا', 'home.mylist': 'قائمتي', 'home.latestMovies': 'أحدث الأفلام', 'home.latestSeries': 'أحدث المسلسلات', 'home.liveChannels': 'قنوات مباشرة', 'home.latestMovie': 'أحدث فيلم', 'home.onNow': 'يُعرض الآن — قنواتي', 'home.onNowHint': 'أضف قنوات إلى قائمتي (الزر الأحمر) لترى ما يُعرض الآن.', 'home.empty': 'لا يوجد شيء بعد. تصفّح البث المباشر أو الأفلام أو المسلسلات.', 'home.latestAddition': 'أحدث إضافة', 'home.featured': 'مميّز', 'home.trending': 'الأعلى تقييمًا',
    'home.live': 'مباشر', 'home.upnext': 'التالي', 'home.min': 'د', 'home.left': 'متبقية',
    'categories': 'الفئات', 'allChannels': 'كل القنوات', 'allMovies': 'كل الأفلام', 'allSeries': 'كل المسلسلات', 'selectChannel': 'اختر قناة', 'noEpg': 'لا يوجد دليل برامج', 'noChannels': 'لا توجد قنوات في هذه الفئة.', 'noEpisodes': 'لا توجد حلقات.', 'locked': 'مقفلة', 'lockedChannel': 'قناة مقفلة', 'enterPin': 'أدخل الرمز لفتحها', 'lockChannel': 'قفل القناة', 'unlockChannel': 'إلغاء قفل القناة', 'channelLocked': 'تم قفل القناة', 'channelUnlocked': 'تم إلغاء قفل القناة', 'setPinFirst': 'عيّن رمز PIN للبروفايل أولًا (إدارة البروفايلات) لقفل القنوات.',
    'fav.channels': 'القنوات المفضلة', 'fav.movies': 'الأفلام المفضلة', 'fav.series': 'المسلسلات المفضلة', 'fav.empty': 'قائمتك فارغة. اضغط الزر الأحمر أو ☆ على أي قناة أو فيلم أو مسلسل.', 'search.ph': 'ابحث عن قنوات، أفلام، مسلسلات…', 'search.min': 'اكتب حرفين على الأقل.', 'search.channels': 'قنوات', 'search.movies': 'أفلام', 'search.series': 'مسلسلات', 'search.none': 'لا نتائج لـ «{q}»', 'search.abc': 'ABC', 'search.ar': 'عربي',
    'settings': 'الإعدادات', 'set.language': 'اللغة', 'set.language.d': 'لغة الواجهة واتجاه العرض.', 'set.theme': 'المظهر', 'set.theme.d': 'أورورا · منتصف الليل · OLED · المحيط · قرمزي · زمرّدي · غروب · ملكي', 'set.liveFormat': 'صيغة البث المباشر', 'set.liveFormat.d': 'لـ Xtream فقط. HLS يعمل على أجهزة أكثر؛ TS أقل تأخيرًا.', 'set.engine': 'محرك التشغيل', 'set.engine.d': 'تلقائي يجرّب المشغّل الأصلي ثم hls.js.', 'set.parental': 'الرقابة الأبوية', 'set.parental.d': 'إخفاء فئات البالغين.', 'set.preview': 'نافذة المعاينة المباشرة', 'set.preview.d': 'تشغيل القناة المحددة في نافذة صغيرة. أوقفها على الأجهزة البطيئة.', 'set.autostart': 'تشغيل آخر بروفايل تلقائيًا', 'set.autostart.d': 'تخطي شاشة البروفايلات عند الفتح (الرمز مطلوب إن وُجد).', 'set.refresh': 'تحديث القوائم تلقائيًا', 'set.refresh.d': 'إعادة تحميل القنوات والأفلام والمسلسلات في الخلفية وإشعارك بالمحتوى الجديد.', 'set.tmdb': 'صور وتقييمات TMDB', 'set.tmdb.d': 'اختياري. ألصق مفتاح TMDB API (v3) لإثراء الأفلام والمسلسلات بالخلفيات والقصة والتقييم.', 'set.cache': 'مسح الذاكرة المؤقتة', 'set.cache.d': 'حذف الفئات والقوائم ودليل البرامج والصور المخزّنة.', 'set.profile': 'البروفايل', 'set.about': 'حول', 'set.exit': 'إغلاق التطبيق', 'set.refreshNow': 'تحديث الآن', 'set.lockedKids': 'مقفل (أطفال)',
    'theme.aurora': 'أورورا', 'theme.midnight': 'منتصف الليل', 'theme.oled': 'OLED أسود', 'theme.ocean': 'المحيط',
    'refresh.off': 'متوقف', 'refresh.h': 'كل {h} ساعات',
    'p.audio': 'الصوت', 'p.subs': 'الترجمة', 'p.channels': 'القنوات', 'p.stats': 'إحصائيات', 'p.fit': 'ملائمة', 'p.fill': 'ملء', 'p.stretch': 'تمديد', 'p.aspect': 'الأبعاد: {m}', 'p.noChannel': 'لا توجد قناة {n}', 'p.retryHint': '— توقف بعد {max} محاولات. اضغط OK لإعادة المحاولة.', 'p.interrupted': 'انقطع البث — إعادة الاتصال ({n}/{max})', 'p.stalled': 'توقف البث', 'p.error': 'خطأ في التشغيل', 'p.cannotLoad': 'تعذّر تحميل البث', 'p.zapHint': 'OK: تبديل · BACK: إلغاء',
    'stats.title': 'إحصائيات البث', 'stats.res': 'الدقة', 'stats.bitrate': 'معدل البت', 'stats.dropped': 'إطارات مفقودة', 'stats.decoded': 'إطارات مفكوكة', 'stats.buffer': 'المخزن المؤقت', 'stats.codec': 'الترميز / الحاوية', 'stats.engine': 'المحرك', 'stats.latency': 'تأخير البث', 'stats.url': 'الرابط', 'stats.unknown': 'غير متاح', 'stats.native': 'أصلي (webOS)', 'stats.hlsjs': 'hls.js',
    'toast.favAdd': 'أُضيف إلى قائمتي', 'toast.favDel': 'أُزيل من قائمتي', 'toast.cache': 'تم مسح الذاكرة المؤقتة', 'toast.newContent': 'أُضيف {n} عنصر جديد إلى قائمتك', 'toast.newMovies': '{n} فيلم جديد', 'toast.newSeries': '{n} مسلسل جديد', 'toast.newLive': '{n} قناة جديدة', 'toast.refreshed': 'تم تحديث القوائم — لا يوجد محتوى جديد', 'toast.refreshing': 'جارٍ تحديث القوائم…', 'toast.expires': 'الاشتراك: {t}',
    'exp.expired': 'منتهي', 'exp.today': 'ينتهي اليوم', 'exp.one': 'ينتهي خلال يوم', 'exp.days': 'ينتهي خلال {d} يومًا', 'exp.unlimited': 'غير محدود',
    'exit.title': 'الخروج من RGBTv؟', 'exit.text': 'تبديل البروفايل أم إغلاق التطبيق؟', 'exit.switch': 'تبديل البروفايل', 'exit.close': 'إغلاق التطبيق؟',
    'kids.locked': 'الرقابة الأبوية مقفلة لبروفايلات الأطفال',
    'wrongPin': 'رمز خاطئ، حاول مجددًا', 'enterPin4': 'أدخل الرمز المكوّن من 4 أرقام', 'pinProtected': 'هذا البروفايل محمي'
  };
  var LANGS = { en: EN, ar: AR }, lang = 'en', dict = EN;

  function t(key, vars) {
    var s = dict[key]; if (s == null) s = EN[key]; if (s == null) return key;
    if (vars) for (var k in vars) s = s.split('{' + k + '}').join(vars[k]);
    return s;
  }
  function get() { return lang; }
  function isRTL() { return lang === 'ar'; }
  function set(l) {
    lang = LANGS[l] ? l : 'en'; dict = LANGS[lang];
    document.documentElement.setAttribute('lang', lang);
    document.documentElement.setAttribute('dir', isRTL() ? 'rtl' : 'ltr');
    document.body.classList.toggle('rtl', isRTL());
    apply(document);
  }
  /* translate static markup */
  function apply(root) {
    U.$$('[data-i18n]', root).forEach(function (e) { e.textContent = t(e.getAttribute('data-i18n')); });
    U.$$('[data-i18n-ph]', root).forEach(function (e) { e.setAttribute('placeholder', t(e.getAttribute('data-i18n-ph'))); });
    U.$$('[data-i18n-html]', root).forEach(function (e) { e.innerHTML = t(e.getAttribute('data-i18n-html')); });
  }
  function next() { return lang === 'en' ? 'ar' : 'en'; }
  function name(l) { return l === 'ar' ? 'العربية' : 'English'; }
  return { t: t, set: set, get: get, isRTL: isRTL, apply: apply, next: next, name: name };
})();
